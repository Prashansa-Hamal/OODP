package test;

import view.QuizFrame;
import org.junit.jupiter.api.Test;

import javax.swing.*;

import static org.junit.jupiter.api.Assertions.*;

public class QuizFrameTest {

    @Test
    public void testQuizFrameCreation() {
        SwingUtilities.invokeLater(() -> {
            QuizFrame quizFrame = new QuizFrame(1); // Mock player ID
            assertNotNull(quizFrame, "QuizFrame should be created");
            quizFrame.dispose(); // Clean up after test
        });
    }
}
