package test;

import controller.QuizController;
import model.Question;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class QuizControllerTest {

    private QuizController quizController;

    @BeforeEach
    public void setUp() {
        quizController = new QuizController();
    }

    @Test
    public void testGetQuestionsByLevel_Beginner() {
        List<Question> questions = quizController.getQuestionsByLevel("Beginner");
        assertNotNull(questions, "Beginner questions should not be null");
        assertFalse(questions.isEmpty(), "Beginner questions list should not be empty");
    }

    @Test
    public void testGetQuestionsByLevel_Intermediate() {
        List<Question> questions = quizController.getQuestionsByLevel("Intermediate");
        assertNotNull(questions, "Intermediate questions should not be null");
        assertFalse(questions.isEmpty(), "Intermediate questions list should not be empty");
    }

    @Test
    public void testGetQuestionsByLevel_Advanced() {
        List<Question> questions = quizController.getQuestionsByLevel("Advanced");
        assertNotNull(questions, "Advanced questions should not be null");
        assertFalse(questions.isEmpty(), "Advanced questions list should not be empty");
    }

    @Test
    public void testGetQuestionsByInvalidLevel() {
        List<Question> questions = quizController.getQuestionsByLevel("InvalidLevel");
        assertNotNull(questions, "Questions should not be null");
        assertTrue(questions.isEmpty(), "Invalid level should return empty list");
    }
}
