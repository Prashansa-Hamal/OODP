package test;

import db.ReportDAO;
import model.Report;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ReportDAOTest {

    private ReportDAO reportDAO;

    @BeforeEach
    void setUp() {
        reportDAO = new ReportDAO();
    }

    @Test
    public void testAddReport() {
        Report report = new Report(1, 6, 4, 60, "Intermediate"); // Mock data
        boolean result = reportDAO.addReport(report);
        assertTrue(result, "Report should be added successfully");
    }

    @Test
    public void testGetReportsForPlayer() {
        List<Report> reports = reportDAO.getReportsForPlayer(1); // Assuming player ID 1 exists
        assertNotNull(reports, "Report list should not be null");
        assertFalse(reports.isEmpty(), "Reports list should not be empty");
    }

    @Test
    public void testReportValues() {
        List<Report> reports = reportDAO.getReportsForPlayer(1);
        assertTrue(reports.size() > 0, "Player should have at least one report");
        Report report = reports.get(0);
        assertTrue(report.getCorrectAnswers() >= 0 && report.getCorrectAnswers() <= report.getTotalQuestions(),
                   "Correct answers should be between 0 and totalQuestions");
        assertTrue(report.getWrongAnswers() >= 0 && report.getWrongAnswers() <= report.getTotalQuestions(),
                   "Wrong answers should be between 0 and totalQuestions");
        assertTrue(report.getScore() >= 0, "Score should not be negative");
    }
}
