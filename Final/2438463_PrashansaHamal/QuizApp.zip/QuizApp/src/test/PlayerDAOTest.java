package test;

import db.PlayerDAO;
import model.Player;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PlayerDAOTest {

    private PlayerDAO playerDAO;
    private String uniqueEmail;
    private String password;

    @BeforeEach
    void setUp() {
        playerDAO = new PlayerDAO();
        
        // Generate a unique email and password for the test
        uniqueEmail = "Test" + System.currentTimeMillis() + "@gmail.com";
        password = "#123";
        
        // Register the new player
        Player newPlayer = new Player(uniqueEmail, password, "Prashansa", "Intermediate");
        playerDAO.registerPlayer(newPlayer);
    }

    @Test
    public void testLoginPlayer_ValidCredentials() {
        // Use the generated email and password for login
        int playerId = playerDAO.loginPlayer(uniqueEmail, password); 
        assertTrue(playerId > 0, "Player login should return a valid ID");
    }

    @Test
    public void testLoginPlayer_InvalidCredentials() {
        int playerId = playerDAO.loginPlayer("wronguser", "wrongpassword");
        assertEquals(-1, playerId, "Invalid login should return -1");
    }

    @Test
    public void testGetPlayerDifficulty() {
        String difficulty = playerDAO.getPlayerDifficulty(1); // Assuming player ID 1 exists
        assertNotNull(difficulty, "Difficulty level should not be null");
        assertTrue(difficulty.equals("Beginner") || difficulty.equals("Intermediate") || difficulty.equals("Advanced"),
                "Difficulty should be Beginner, Intermediate, or Advanced");
    }

    @Test
    public void testRegisterNewPlayer() {
        // Generate a unique email for each test run to avoid duplication in the database
        String uniqueEmail = "Test" + System.currentTimeMillis() + "@gmail.com"; 
        
        // Create Player object with the unique email
        Player newPlayer = new Player(uniqueEmail, "#123", "Prashansa", "Intermediate");
        
        // Register the player
        boolean isRegistered = playerDAO.registerPlayer(newPlayer); 
        
        // Assert that the player was successfully registered
        assertTrue(isRegistered, "New player should be registered successfully");
    }
}
