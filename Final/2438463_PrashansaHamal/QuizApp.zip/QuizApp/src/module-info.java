/**
 * 
 */
/**
 * 
 */
module QuizApp {
    requires java.desktop;
    requires java.sql;
    requires org.junit.jupiter.api;  // Required for JUnit 5
    requires junit;
	requires org.junit.platform.engine; // Required for JUnit 5

    exports test to junit;
    opens test to junit;
}

